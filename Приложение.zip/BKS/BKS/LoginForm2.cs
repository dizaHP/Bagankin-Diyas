﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BKS
{
    public partial class LoginForm2 : Form
    {
        public LoginForm2()
        {
            InitializeComponent();
            form2 = new adminForm1();  
        }

        private void LoginForm2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        adminForm1 form2;
        string Login = "Admin";
        string Password = "589622d";
        private void button1_Click(object sender, EventArgs e)
        {
            string log = textBox1.Text;
            string pas = textBox2.Text;
            if (log == Login && pas == Password)
            {
                form2.Show();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль", "Внимание");
            }

        }
    }
}
